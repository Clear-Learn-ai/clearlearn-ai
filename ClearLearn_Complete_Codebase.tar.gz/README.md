# Clearlearn - Adaptive Visual Learning System

A production-ready foundation for an AI tutor that explains any concept through multiple modalities.

## 🎯 Project Overview

Clearlearn is designed to handle millions of users and thousands of concepts through a scalable, modular architecture. **Day 2 Complete** - Now featuring multiple content generators with intelligent routing and fallback mechanisms.

## 🏗️ Architecture

The system follows a clean, modular architecture designed for production scale:

```
├── /core                   # Learning engine logic
│   ├── LearningEngine.ts   # Main orchestration class
│   └── types.ts           # Core type definitions
├── /generators            # Content generation modules
│   └── AnimatedDiagramGenerator.ts
├── /adapters              # User model and adaptation logic
├── /components            # Reusable UI components
│   ├── QueryInput.tsx     # Smart query input with autocomplete
│   ├── ContentDisplay.tsx # Dynamic content renderer
│   ├── AnimationRenderer.tsx # Canvas-based animation engine
│   └── FeedbackMechanism.tsx # User feedback collection
├── /api                   # Backend API routes
└── /lib                   # Shared utilities and state management
    ├── store.ts           # Zustand state management
    └── utils.ts           # Utility functions
```

## 🚀 Features

### Core Engine
- **LearningEngine**: Orchestrates the entire learning pipeline
- **Concept Parser**: Analyzes natural language queries
- **Modality Selector**: Chooses optimal presentation format
- **Session Manager**: Tracks user learning journey
- **Performance Tracker**: Measures comprehension signals

### Content Generation (Day 2 - Multi-Modal)
- **AnimatedDiagramGenerator**: Creates smooth Canvas API animations
- **InteractiveSimulationGenerator**: Physics/biological simulations with real-time controls
- **Model3DGenerator**: Rotatable 3D models (DNA, molecules, anatomy, solar system)
- **ConceptMapGenerator**: Interactive knowledge graphs with force-directed layouts
- **Intelligent Modality Selector**: Analyzes concepts to choose optimal visualization
- **Fallback Chain System**: Ensures content delivery even if primary generator fails

### User Interface
- **Smart Query Input**: Autocomplete and suggested queries
- **Dynamic Content Display**: Supports multiple content modalities
- **Interactive Controls**: Play/pause, step navigation, progress tracking
- **Feedback System**: Multi-dimensional user feedback collection

## 🧪 Test Cases: Multi-Modal Learning

The system now supports diverse concepts with intelligent routing:

### **Simulations (Interactive Physics/Biology)**
- **"How does gravity work?"** → Interactive gravity simulation with mass/distance controls
- **"Water cycle"** → Environmental parameter simulation
- **"How does photosynthesis work?"** → CO2/light/temperature manipulation

### **3D Models (Structural Visualization)**
- **"Structure of DNA"** → Rotatable double helix with base pair details
- **"Cell structure"** → Anatomical organelle exploration
- **"Molecular structure"** → Atomic bond visualization

### **Concept Maps (System Understanding)**
- **"How do neural networks learn?"** → Interactive learning algorithm graph
- **"How does the internet work?"** → Network infrastructure relationships

### **Animations (Process Explanation)**
- **"How does photosynthesis work?"** → Step-by-step animated process

## 🛠️ Tech Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS with custom animations
- **State Management**: Zustand with selectors
- **Graphics**: Canvas API, Three.js (planned), P5.js (planned), D3.js
- **Visualization**: Custom renderers for each modality
- **Build Tools**: ESLint, TypeScript compiler

## 🏃‍♀️ Getting Started

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start development server**:
   ```bash
   npm run dev
   ```

3. **Open browser**: Navigate to `http://localhost:3000`

4. **Try the demos**: 
   - **Simulation**: "How does gravity work?"
   - **3D Model**: "Structure of DNA"
   - **Concept Map**: "How do neural networks learn?"
   - **Animation**: "How does photosynthesis work?"

## 🔧 Development Commands

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server

# Quality Assurance
npm run lint         # Run ESLint
npm run type-check   # TypeScript compilation check
```

## 📁 Key Files

### Core Logic
- `core/LearningEngine.ts` - Main orchestration engine
- `core/types.ts` - TypeScript definitions for all data structures

### Content Generation
- `generators/AnimatedDiagramGenerator.ts` - Canvas animation generator
- Sample implementation for photosynthesis with extensible patterns

### UI Components
- `components/QueryInput.tsx` - Smart query interface
- `components/AnimationRenderer.tsx` - Canvas-based animation player
- `components/FeedbackMechanism.tsx` - User feedback collection

### State Management
- `lib/store.ts` - Zustand store with optimized selectors
- Tracks queries, content, feedback, and session metrics

## 🎨 Design Principles

### Scalability
- Modular architecture for easy extension
- Optimized state management with selective subscriptions
- Lazy loading and code splitting ready

### Performance
- Canvas-based animations for 60fps smoothness
- Efficient re-renders with proper memoization
- TypeScript strict mode for catch errors early

### Extensibility
- Plugin-like generator system
- Type-safe interfaces for all components
- Clear separation of concerns

## ✅ Day 2 Complete - What's New

1. **✅ Three Content Generators Added**: Simulation, 3D Model, Concept Map
2. **✅ Intelligent Modality Selection**: Rules-based routing to optimal visualization
3. **✅ Fallback Chain System**: Ensures content delivery with graceful degradation
4. **✅ Unified Content Renderer**: Dynamic loading of appropriate viewers
5. **✅ Multiple Test Concepts**: Gravity, DNA, neural networks, water cycle, internet

## 🚀 Next Steps (Day 3-4)

1. **Real 3D Integration**: Replace placeholders with actual Three.js implementations
2. **Advanced Simulations**: P5.js physics engines for complex interactions
3. **User Adaptation**: AI-powered personalization based on learning patterns
4. **Performance Optimization**: Caching, lazy loading, analytics
5. **Real-time Features**: Collaborative learning, live feedback

## 🧪 Testing the System

Try these sample queries to test different aspects:

- "How does photosynthesis work?" - Full animation demo
- "Explain cellular respiration" - Fallback generic animation
- "What is DNA replication?" - Concept analysis demonstration

## 📊 Monitoring

The system tracks comprehensive metrics:
- Query processing performance
- User engagement patterns
- Content effectiveness ratings
- Session completion rates

All metrics are logged and available through the development store for analysis.

---

Built with ❤️ for adaptive learning experiences.